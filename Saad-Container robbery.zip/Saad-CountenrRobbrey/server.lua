local QBCore = exports['qb-core']:GetCoreObject()

local Containers = {}

local function GetContainer(index)
    if not Containers[index] then
        Containers[index] = {
            attempts = 0,
            locked = true,
            disabled = false,
            looted = false
        }
    end
    return Containers[index]
end

RegisterNetEvent("saad_containerrob:TryDrill", function(index)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local container = GetContainer(index)

    if container.disabled or (container.locked and container.attempts >= Config.MaxAttempts) then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleBlocked, 'error')
        return
    end

    if not container.locked then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleAlreadyOpen, 'error')
        return
    end

    local Drill = Player.Functions.GetItemByName(Config.DrillItem)
    if not Drill or Drill.amount < 1 then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleNoDrill, 'error')
        return
    end

    TriggerClientEvent("saad_containerrob:DispatchRobbery", src)
    TriggerClientEvent("saad_containerrob:StartMinigame", src, index)
end)

RegisterNetEvent("saad_containerrob:MinigameResult", function(index, success)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local container = GetContainer(index)
    if container.disabled or not container.locked then return end

    if success then
        container.locked = false
        container.attempts = 0

        local removed = Player.Functions.RemoveItem(Config.DrillItem, 1)
        if removed then
            if QBCore.Shared.Items[Config.DrillItem] then
                TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[Config.DrillItem], 'remove')
            end
        end

        TriggerClientEvent('QBCore:Notify', src, Config.LocaleUnlocked, 'success')
        TriggerClientEvent("saad_containerrob:OpenContainer", src, index)
    else
        container.attempts = container.attempts + 1
        if container.attempts >= Config.MaxAttempts then
            container.disabled = true
            TriggerClientEvent('QBCore:Notify', src, Config.LocaleBlocked, 'error')
        else
            TriggerClientEvent('QBCore:Notify', src, Config.LocaleTryAgain .. ' (' .. container.attempts .. '/' .. Config.MaxAttempts .. ')', 'error')
        end
    end
end)

RegisterNetEvent("saad_containerrob:AttemptLoot", function(index)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local container = GetContainer(index)

    if container.locked then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleLocked, 'error')
        return
    end

    if container.disabled then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleBlocked, 'error')
        return
    end

    if container.looted then
        TriggerClientEvent('QBCore:Notify', src, Config.LocaleAlreadyLooted, 'error')
        return
    end

    TriggerClientEvent("saad_containerrob:LootContainer", src, index)
end)

RegisterNetEvent("saad_containerrob:FinishLoot", function(index)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local container = GetContainer(index)
    if container.looted then
        return
    end

    container.looted = true

    for _, itemData in ipairs(Config.LootTable) do
        local roll = math.random(100)
        if roll <= itemData.chance then
            local amount = math.random(itemData.min, itemData.max)
            if amount > 0 then
                Player.Functions.AddItem(itemData.item, amount)
                if QBCore.Shared.Items[itemData.item] then
                    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[itemData.item], 'add')
                end
            end
        end
    end

    TriggerClientEvent("saad_containerrob:DispatchRobbery", src)
end)
