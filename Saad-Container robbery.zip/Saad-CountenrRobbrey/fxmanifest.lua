fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Saad'
description 'Container robbery with minigame Drilling'
version '1.0.0'

shared_script 'config.lua'

client_scripts {
    'utils.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}
