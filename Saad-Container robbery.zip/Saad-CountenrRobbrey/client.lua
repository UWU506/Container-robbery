local QBCore = exports['qb-core']:GetCoreObject()

local Containers = {}
local TargetZones = {}
local SpawnedObjects = {}

local function spawnObject(model, coords)
    local propHash = type(model) == 'string' and joaat(model) or model
    loadModel(propHash)
    local object = CreateObject(propHash, coords.x, coords.y, coords.z, true, true, false)
    while not DoesEntityExist(object) do
        Wait(10)
    end
    SetEntityAsMissionEntity(object, true, true)
    FreezeEntityPosition(object, true)
    SetEntityHeading(object, coords.w)
    SetModelAsNoLongerNeeded(propHash)
    return object
end

local function spawnContainer(coords)
    loadAnimDict(Config.containerAnim.dict)
    local container = spawnObject(Config.props.container, vector4(coords.x, coords.y, coords.z -0.4 , coords.w - 180.0))
    local containerCoords = GetEntityCoords(container)

    local lockCoords = GetAnimInitialOffsetPosition(
        Config.containerAnim.dict,
        Config.containerAnim.lock,
        GetEntityCoords(container),
        GetEntityRotation(container),
        0.0,
        0
    )
    local lock = spawnObject(Config.props.lock, vector4(lockCoords, coords.w - 180.0))
    SetEntityCoords(lock, lockCoords)

    local crateCoords = GetObjectOffsetFromCoords(coords, 0.0, -0.6, -0.8)
    local crate = spawnObject(Config.props.crate, vector4(crateCoords, coords.w + 90.0))

    local collision = spawnObject(Config.props.containerCollison, vector4(containerCoords, coords.w - 180.0))
    SetEntityCoords(collision, containerCoords, false, false, false)
    SetEntityCollision(collision, false, false)

    local props = {
        container = container,
        lock = lock,
        crate = crate,
        collision = collision,
        lockCoords = vector4(lockCoords, coords.w),
        crateCoords = vector4(crateCoords, coords.w + 90.0)
    }
    return props
end


local function doContainerAnim(index, containerNetId, lockNetId, collisionNetId)
    local container = NetworkGetEntityFromNetworkId(containerNetId)
    local lock = NetworkGetEntityFromNetworkId(lockNetId)
    local collision = NetworkGetEntityFromNetworkId(collisionNetId)

    NetworkRequestControlOfEntity(container)
    NetworkRequestControlOfEntity(lock)
    local timer = GetGameTimer()
    while (not NetworkHasControlOfEntity(container) or not NetworkHasControlOfEntity(lock)) and GetGameTimer() - timer < 5000 do
        Wait(0)
    end

    loadAnimDict(Config.containerAnim.dict)
    loadPtfx(Config.containerAnim.ptfx)
    loadAudio(Config.containerAnim.audioBank)

    local grinderHash = joaat(Config.props.grinder)
    local bagHash = joaat(Config.props.bag)
    loadModel(grinderHash)
    loadModel(bagHash)

    local ped = PlayerPedId()
    local containerCoords = GetEntityCoords(container)
    local containerRot = GetEntityRotation(container)
    local playerCoords = GetEntityCoords(ped)
    local grinder = CreateObject(grinderHash, playerCoords.x, playerCoords.y, playerCoords.z, true, true, false)
    local bag = CreateObject(bagHash, playerCoords.x, playerCoords.y, playerCoords.z, true, true, false)
    SetEntityCollision(bag, false, false)

    FreezeEntityPosition(ped, true)

    local containerScene = NetworkCreateSynchronisedScene(containerCoords, containerRot, 2, true, false, 1.0, 0.0, 1.0)
    NetworkAddPedToSynchronisedScene(ped, containerScene, Config.containerAnim.dict, Config.containerAnim.player, 10.0, -4.0, 1, 0, 1148846080, 0)
    NetworkAddEntityToSynchronisedScene(lock, containerScene, Config.containerAnim.dict, Config.containerAnim.lock, 2.0, -4.0, 134149, 0)
    NetworkAddEntityToSynchronisedScene(grinder, containerScene, Config.containerAnim.dict, Config.containerAnim.grinder, 2.0, -4.0, 134149, 0)
    NetworkAddEntityToSynchronisedScene(bag, containerScene, Config.containerAnim.dict, Config.containerAnim.bag, 2.0, -4.0, 134149, 0)
    NetworkStartSynchronisedScene(containerScene)

    PlayEntityAnim(container, Config.containerAnim.container, Config.containerAnim.dict, 8.0, false, true, false, 0, 0)

    CreateThread(function()
        while NetworkGetLocalSceneFromNetworkId(containerScene) == -1 do
            Wait(0)
        end
        local localScene = NetworkGetLocalSceneFromNetworkId(containerScene)
        local ptfx
        while IsSynchronizedSceneRunning(localScene) do
            if HasAnimEventFired(ped, -1953940906) then
                UseParticleFxAssetNextCall(Config.containerAnim.ptfx)
                ptfx = StartNetworkedParticleFxLoopedOnEntity("scr_tn_tr_angle_grinder_sparks", grinder, 0.0, 0.25, 0.0, 0.0, 0.0, 0.0, 1.0, false, false, false)
            elseif HasAnimEventFired(ped, -258875766) then
                if ptfx then
                    StopParticleFxLooped(ptfx, false)
                end
            end
            Wait(0)
        end
    end)

    local duration = GetAnimDuration(Config.containerAnim.dict, Config.containerAnim.container)
    Wait(math.floor(duration * 1000))

    FreezeEntityPosition(ped, false)
    ClearPedTasks(ped)

    DeleteObject(grinder)
    DeleteObject(lock)
    DeleteObject(bag)

    local data = Containers[index]
    if not data then return end

    local containerEntity = NetworkGetEntityFromNetworkId(containerNetId)
    local collisionEntity = NetworkGetEntityFromNetworkId(collisionNetId)
    SetEntityCollision(collisionEntity, true, true)
    SetEntityCompletelyDisableCollision(containerEntity, false, false)

    local lockZone = "rob_lock_" .. index
    if TargetZones[lockZone] then
        exports['qb-target']:RemoveZone(lockZone)
        TargetZones[lockZone] = nil
    end

    local crateZone = "rob_crate_" .. index
    local crateCoords = data.crateCoords
    local min, max = GetModelDimensions(joaat(Config.props.crate))
    local crateDimensions = vector3(max.x - min.x, max.y - min.y, max.z - min.z)

    exports['qb-target']:AddBoxZone(crateZone, vector3(crateCoords.x, crateCoords.y, crateCoords.z), crateDimensions.y, crateDimensions.x, {
        name = crateZone,
        heading = crateCoords.w,
        debugPoly = Config.Debug,
        minZ = crateCoords.z,
        maxZ = crateCoords.z + crateDimensions.z
    }, {
        options = {
            {
                icon = "fa-solid fa-boxes-stacked",
                label = "Loot",
                action = function()
                    TriggerServerEvent("saad_containerrob:AttemptLoot", index)
                end
            }
        },
        distance = 2.0
    })
    TargetZones[crateZone] = true

    RemoveNamedPtfxAsset(Config.containerAnim.ptfx)
    ReleaseNamedScriptAudioBank(Config.containerAnim.audioBank)
    RemoveAnimDict(Config.containerAnim.dict)
end

CreateThread(function()
    for index, coords in ipairs(Config.Containers) do
        local props = spawnContainer(coords)
        local netIds = {
            container = NetworkGetNetworkIdFromEntity(props.container),
            lock = NetworkGetNetworkIdFromEntity(props.lock),
            crate = NetworkGetNetworkIdFromEntity(props.crate),
            collision = NetworkGetNetworkIdFromEntity(props.collision)
        }
        Containers[index] = {
            netIds = netIds,
            crateCoords = props.crateCoords
        }

        SpawnedObjects[index] = {
            props.container,
            props.lock,
            props.crate,
            props.collision
        }

        local lockZone = "rob_lock_" .. index
        local min, max = GetModelDimensions(joaat(Config.props.lock))
        local lockDimensions = vector3(max.x - min.x, max.y - min.y, max.z - min.z)

        exports['qb-target']:AddBoxZone(lockZone, vector3(props.lockCoords.x, props.lockCoords.y, props.lockCoords.z), lockDimensions.y, lockDimensions.x, {
            name = lockZone,
            heading = props.lockCoords.w,
            debugPoly = Config.Debug,
            minZ = props.lockCoords.z - lockDimensions.z / 2,
            maxZ = props.lockCoords.z + lockDimensions.z / 2
        }, {
            options = {
                {
                    icon = "fa-solid fa-unlock",
                    label = "Drill",
                    action = function()
                        TriggerServerEvent("saad_containerrob:TryDrill", index)
                    end
                }
            },
            distance = 2.0
        })
        TargetZones[lockZone] = true
    end
end)

RegisterNetEvent("saad_containerrob:StartMinigame", function(index)
    exports['skillchecks']:startAlphabetGame(8000, 20, function(success)
        TriggerServerEvent("saad_containerrob:MinigameResult", index, success)
    end)
end)

RegisterNetEvent("saad_containerrob:OpenContainer", function(index)
    local data = Containers[index]
    if not data then return end
    doContainerAnim(index, data.netIds.container, data.netIds.lock, data.netIds.collision)
end)

RegisterNetEvent("saad_containerrob:LootContainer", function(index)
    local ped = PlayerPedId()
    loadAnimDict(Config.lootAnim.dict)
    TaskPlayAnim(ped, Config.lootAnim.dict, Config.lootAnim.anim, 1.0, 1.0, -1, 1, 0, false, false, false)
    QBCore.Functions.Progressbar("looting_crate", Config.LocaleLooting, Config.LootTime, false, true, {
        disableMovement = true,
        disableCarMovement = true,
        disableMouse = false,
        disableCombat = true
    }, {}, {}, {}, function()
        ClearPedTasks(ped)
        TriggerServerEvent("saad_containerrob:FinishLoot", index)
    end, function()
        ClearPedTasks(ped)
        QBCore.Functions.Notify("Cancelled", "error")
    end)
end)

RegisterNetEvent("saad_containerrob:DispatchRobbery", function()
    if GetResourceState('cd_dispatch') ~= 'started' then return end

    local data = exports['cd_dispatch']:GetPlayerInfo()
    local sexText = (data.sex == "male" and "A man is robbing") or (data.sex == "female" and "A woman is robbing") or "Someone is robbing"

    TriggerServerEvent('cd_dispatch:AddNotification', {
        job_table = { 'police' },
        coords = data.coords,
        title = "Container Robbery",
        message = sexText .. " the container.",
        flash = 1,
        unique_id = tostring(math.random(1000000, 9999999)),
        blip = {
            sprite = 431,
            scale = 1.0,
            colour = 1,
            flashes = false,
            text = "Container Robbery",
            time = (5 * 60 * 1000),
            sound = 1
        }
    })
end)

AddEventHandler('onResourceStop', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end

    for zone, _ in pairs(TargetZones) do
        exports['qb-target']:RemoveZone(zone)
    end
    TargetZones = {}

    for _, objs in pairs(SpawnedObjects) do
        for _, ent in ipairs(objs) do
            if ent and DoesEntityExist(ent) then
                DeleteObject(ent)
            end
        end
    end
    SpawnedObjects = {}
end)
