Config = {}

Config.Debug = false

Config.DrillItem = 'drill'
Config.MaxAttempts = 3


Config.LootTime = 5000

Config.Containers = {
    vector4(1053.98, -3036.93, 5.29, 270.31), -- L1
    vector4(1054.09, -3039.58, 5.29, 270.93), -- L1
    vector4(1054.21, -3042.21, 5.29, 271.55), -- L1
    vector4(1165.87, -2978.90, 5.3, 270.06), -- L2
    vector4(1165.87, -2976.19, 5.3, 270.02), -- L2
    vector4(1165.87, -2973.55, 5.3, 269.98), -- L2
    vector4(1165.87, -2970.88, 5.3, 269.69), -- L2
    vector4(1165.87, -2968.15, 5.3, 269.39), -- L2
    vector4(1174.71, -2978.99, 5.29, 270.22), -- L2.5
    vector4(1174.71, -2976.32, 5.29, 270.22), -- L2.5
    vector4(1174.11, -2973.65, 5.29, 270.22), -- L2.5
    vector4(1174.71, -2970.98, 5.29, 270.22), -- L2.5
    vector4(1174.71, -2968.31, 5.29, 270.22), -- L2.5
    


}

Config.LootTable = {
    { item = 'rolex',       min = 1, max = 3, chance = 100 },
    { item = 'goldchain',   min = 1, max = 2, chance = 80  },
    { item = 'pistol_ammo', min = 1, max = 1, chance = 50  },
    { item = 'cashroll',    min = 100, max = 250, chance = 50  },
    { item = 'cashroll',   min = 50, max = 90, chance = 100  }
}

Config.props = {
    container = "tr_prop_tr_container_01a",
    containerCollison = "tr_prop_tr_cont_coll_01a",
    lock = "tr_prop_tr_lock_01a",
    grinder = "tr_prop_tr_grinder_01a",
    crate = "tr_prop_tr_crates_sam_01a",
    bag = "hei_p_m_bag_var22_arm_s",
}

Config.containerAnim = {
    dict = "anim@scripted@player@mission@tunf_train_ig1_container_p1@male@",
    bag = "action_bag",
    container = "action_container",
    lock = "action_lock",
    grinder = "action_angle_grinder",
    player = "action",
    audioBank = "dlc_tuner/dlc_tuner_generic",
    ptfx = "scr_tn_tr",
}

Config.lootAnim = {
    dict = "mini@repair",
    anim = "fixing_a_ped",
}

Config.LocaleNoDrill = 'You need a Drill to do this.'
Config.LocaleBlocked = 'This container can no longer be tampered with.'
Config.LocaleEmpty = 'This container is empty.'
Config.LocaleUnlocked = 'You unlocked the container, search the crate.'
Config.LocaleTryAgain = 'Drill failed, try again.'
Config.LocaleLooting = 'Grabbing items...'
Config.LocaleAlreadyOpen = 'The container is already open.'
Config.LocaleLocked = 'The container is locked.'
Config.LocaleAlreadyLooted = 'This container has already been looted.'
